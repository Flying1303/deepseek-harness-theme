# DeepSeek Harness 官网风格皮肤 v1.0.1

视觉灵感来自 DeepSeek Harness 的旧版官方发布页。浅色和深色均有动态极光、星座网格、居中的粒子鲸鱼和磨砂效果。浅色主题基于原作者的 Web 皮肤制作。

在「设置 → 通用设置 → 外观」选择浅色、深色或跟随系统。

## 来源与致谢

- 原版 Web 皮肤作者 [爱玩蛛的少年](https://space.bilibili.com/564770445)（B 站 UID 564770445） · [原版演示](https://www.bilibili.com/video/BV1fVbi63ETW/)
- 桌面端与浅色主题适配 [我不是Flying（B 站）](https://space.bilibili.com/1350238334) / [Flying1303（GitHub）](https://github.com/Flying1303)
- 由 Codex 制作，使用 GPT-6.1 Sol（轻度）。

[项目主页](https://github.com/Flying1303/deepseek-harness-theme)
