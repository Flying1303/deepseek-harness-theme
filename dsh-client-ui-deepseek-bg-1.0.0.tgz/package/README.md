# DeepSeek Harness 官网风格皮肤 v1.0

将旧版官方启动页的动态极光、星座网格、粒子鲸鱼和磨砂效果带到 Harness。鲸鱼跟随主会话区居中，窗口尺寸稳定后再重绘背景。

在「设置 → 通用设置 → 外观」中选择浅色、深色或跟随系统。

## 来源与致谢

- 原版 Web 皮肤作者 [爱玩蛛的少年](https://space.bilibili.com/564770445)（B 站 UID 564770445） · [原版演示](https://www.bilibili.com/video/BV1fVbi63ETW/)
- 桌面端与双主题适配 [Flying1303](https://github.com/Flying1303) · [项目主页](https://github.com/Flying1303/-dsh-deepseek-theme)
