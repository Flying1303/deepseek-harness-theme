# DeepSeek Harness Theme v1.0.1

Inspired by the original official DeepSeek Harness launch page. Both appearances feature animated aurora, a constellation grid, a centered particle whale, and frosted glass. The light theme builds on the original Web skin.

Choose Light, Dark, or System under **Settings → General → Appearance**.

## Credits

- Original Web theme by [爱玩蛛的少年](https://space.bilibili.com/564770445) (Bilibili UID 564770445) · [Original demo](https://www.bilibili.com/video/BV1fVbi63ETW/)
- Desktop and light-theme adaptation by [我不是Flying (Bilibili)](https://space.bilibili.com/1350238334) / [Flying1303 (GitHub)](https://github.com/Flying1303)
- Made with Codex using GPT-6.1 Sol (low reasoning effort).

[Project home](https://github.com/Flying1303/deepseek-harness-theme)
